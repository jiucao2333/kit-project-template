# Python Extension Example [Bitone.BSI.System]

This is an example of pure python Kit extension. It is intended to be copied and serve as a template to create new extensions.

